// Import Firebase SDKs
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.0/firebase-app.js";
import { getDatabase, ref, onValue, update, query, orderByChild } from "https://www.gstatic.com/firebasejs/11.0.0/firebase-database.js";

// Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyA9ADVig4CiO2Y3ELl3unzXajdzxCgRxHI",
  authDomain: "toda-contribution-system.firebaseapp.com",
  databaseURL: "https://toda-contribution-system-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "toda-contribution-system",
  storageBucket: "toda-contribution-system.firebasestorage.app",
  messagingSenderId: "536068566619",
  appId: "1:536068566619:web:ff7cc576e59b76ae58997e"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

// Show notification message
function showMessage(text, type = 'success') {
  const container = document.getElementById('messageContainer');
  const messageId = 'msg-' + Date.now();
  
  const icons = {
    success: '✓',
    error: '✕',
    warning: '⚠',
    info: 'ℹ'
  };
  
  const titles = {
    success: 'Success',
    error: 'Error',
    warning: 'Warning',
    info: 'Information'
  };
  
  const icon = icons[type] || icons.info;
  const title = titles[type] || titles.info;
  
  const messageHTML = `
    <div id="${messageId}" class="message ${type}">
      <span class="message-icon">${icon}</span>
      <div class="message-content">
        <div class="message-title">${title}</div>
        <div class="message-text">${text}</div>
      </div>
    </div>
  `;
  
  container.insertAdjacentHTML('beforeend', messageHTML);
  
  setTimeout(() => {
    const messageEl = document.getElementById(messageId);
    if (messageEl) {
      messageEl.style.opacity = '0';
      setTimeout(() => messageEl.remove(), 300);
    }
  }, 5000);
}

// Custom confirmation dialog
let confirmCallback = null;

function showConfirm(message, title = '⚠️ Confirm Action', confirmText = 'Confirm') {
  return new Promise((resolve) => {
    const modal = document.getElementById('confirmModal');
    const titleEl = document.getElementById('confirmTitle');
    const messageEl = document.getElementById('confirmMessage');
    const confirmBtn = document.getElementById('confirmButton');
    
    titleEl.textContent = title;
    messageEl.textContent = message;
    confirmBtn.textContent = confirmText;
    
    confirmCallback = (result) => {
      modal.classList.remove('active');
      confirmCallback = null;
      resolve(result);
    };
    
    modal.classList.add('active');
  });
}

window.handleConfirm = function() {
  if (confirmCallback) confirmCallback(true);
}

window.closeConfirmModal = function() {
  if (confirmCallback) confirmCallback(false);
}

// Navigation function
window.navigateTo = function(url) {
  window.location.href = url;
}

// Logout function
document.getElementById('logoutBtn')?.addEventListener('click', async () => {
  const confirmResult = await showConfirm(
    'Are you sure you want to logout?',
    '🚪 Logout Confirmation',
    'Logout'
  );
  
  if (confirmResult) {
    // Clear any session data
    sessionStorage.clear();
    localStorage.clear();
    showMessage('Logged out successfully', 'success');
    // Reload page or redirect to login after a short delay
    setTimeout(() => {
      window.location.reload();
    }, 1000);
  }
});

// ===== NOTIFICATION SYSTEM =====
let notifications = [];

// Toggle notification dropdown
window.toggleNotifications = function() {
  const dropdown = document.getElementById('notificationDropdown');
  dropdown.classList.toggle('active');
}

// Close notification dropdown when clicking outside
document.addEventListener('click', function(event) {
  const notificationContainer = document.querySelector('.notification-container');
  const dropdown = document.getElementById('notificationDropdown');
  
  if (notificationContainer && !notificationContainer.contains(event.target)) {
    dropdown?.classList.remove('active');
  }
});

// Mark all notifications as read
window.markAllAsRead = async function() {
  try {
    const notificationsRef = ref(db, 'notifications');
    const updates = {};
    
    notifications.forEach(notif => {
      if (!notif.isRead) {
        updates[`notifications/${notif.id}/isRead`] = true;
      }
    });
    
    if (Object.keys(updates).length > 0) {
      await update(ref(db), updates);
      showMessage('All notifications marked as read', 'success');
    }
  } catch (error) {
    showMessage('Error marking notifications as read: ' + error.message, 'error');
  }
}

// Mark single notification as read
window.markAsRead = async function(notificationId) {
  try {
    const notifRef = ref(db, `notifications/${notificationId}`);
    await update(notifRef, { isRead: true });
  } catch (error) {
    console.error('Error marking notification as read:', error);
  }
}

// Delete notification
window.deleteNotification = async function(notificationId) {
  try {
    const notifRef = ref(db, `notifications/${notificationId}`);
    await update(notifRef, { isRead: true, deleted: true });
    showMessage('Notification deleted', 'success');
  } catch (error) {
    showMessage('Error deleting notification: ' + error.message, 'error');
  }
}

// Handle notification action (e.g., navigate to driver management)
window.handleNotificationAction = function(notification) {
  // Mark as read
  markAsRead(notification.id);
  
  // Navigate based on notification type
  switch(notification.type) {
    case 'RFID_MISSING':
      window.location.href = 'DriverManagement/DriverManagement.html';
      break;
    case 'DRIVER_VERIFICATION':
      window.location.href = 'DriverManagement/DriverManagement.html';
      break;
    case 'DISCOUNT_APPLICATION':
      window.location.href = 'DiscountApplications/DiscountApplications.html';
      break;
    default:
      // Close dropdown
      document.getElementById('notificationDropdown').classList.remove('active');
  }
}

// Format timestamp
function formatNotificationTime(timestamp) {
  const now = Date.now();
  const diff = now - timestamp;
  
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  
  if (minutes < 1) return 'Just now';
  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  if (days < 7) return `${days}d ago`;
  
  const date = new Date(timestamp);
  return date.toLocaleDateString();
}

// Render notifications
function renderNotifications() {
  const notificationList = document.getElementById('notificationList');
  const notificationCount = document.getElementById('notificationCount');
  
  // Filter out deleted notifications and sort by timestamp
  const activeNotifications = notifications
    .filter(n => !n.deleted)
    .sort((a, b) => b.timestamp - a.timestamp);
  
  // Update count (only unread notifications)
  const unreadCount = activeNotifications.filter(n => !n.isRead).length;
  notificationCount.textContent = unreadCount;
  notificationCount.style.display = unreadCount > 0 ? 'flex' : 'none';
  
  // Render notification list
  if (activeNotifications.length === 0) {
    notificationList.innerHTML = `
      <div class="no-notifications">
        <span class="no-notif-icon">🔔</span>
        <p>No notifications yet</p>
      </div>
    `;
    return;
  }
  
  notificationList.innerHTML = activeNotifications.map(notif => {
    const priorityClass = notif.priority === 'high' ? 'high-priority' : '';
    const readClass = notif.isRead ? 'read' : 'unread';
    const actionClass = notif.actionRequired ? 'action-required' : '';
    
    // Get icon based on notification type
    let icon = '🔔';
    if (notif.type === 'RFID_MISSING') icon = '🚨';
    else if (notif.type === 'DRIVER_VERIFICATION') icon = '👤';
    else if (notif.type === 'DISCOUNT_APPLICATION') icon = '🎫';
    
    return `
      <div class="notification-item ${readClass} ${priorityClass} ${actionClass}" 
           onclick="handleNotificationAction(${JSON.stringify(notif).replace(/"/g, '&quot;')})">
        <div class="notification-icon">${icon}</div>
        <div class="notification-content">
          <div class="notification-title">${notif.title}</div>
          <div class="notification-message">${notif.message}</div>
          <div class="notification-time">${formatNotificationTime(notif.timestamp)}</div>
        </div>
        ${!notif.isRead ? '<div class="unread-indicator"></div>' : ''}
      </div>
    `;
  }).join('');
}

// Listen to Firebase notifications
function listenToNotifications() {
  const notificationsRef = ref(db, 'notifications');
  
  onValue(notificationsRef, (snapshot) => {
    if (snapshot.exists()) {
      const data = snapshot.val();
      notifications = Object.keys(data).map(key => ({
        id: key,
        ...data[key]
      }));
      
      renderNotifications();
      
      // Show browser notification for new high-priority notifications
      const newHighPriority = notifications.find(n => 
        !n.isRead && 
        n.priority === 'high' && 
        (Date.now() - n.timestamp) < 5000 // Within last 5 seconds
      );
      
      if (newHighPriority && Notification.permission === 'granted') {
        new Notification(newHighPriority.title, {
          body: newHighPriority.message,
          icon: '🚨',
          tag: newHighPriority.id
        });
      }
    } else {
      notifications = [];
      renderNotifications();
    }
  }, (error) => {
    console.error('Error listening to notifications:', error);
  });
}

// Request notification permission
function requestNotificationPermission() {
  if ('Notification' in window && Notification.permission === 'default') {
    Notification.requestPermission();
  }
}

// ===== END NOTIFICATION SYSTEM =====

// Check Firebase connection and load data
async function initializeDashboard() {
  try {
    // Request notification permission
    requestNotificationPermission();
    
    // Start listening to notifications
    listenToNotifications();
    
    // Load statistics
    loadStats();
    
    // Listen for pending discount applications
    const discountRef = ref(db, 'users');
    onValue(discountRef, (snapshot) => {
      if (snapshot.exists()) {
        let pendingCount = 0;
        const users = snapshot.val();

        Object.keys(users).forEach(userId => {
          const user = users[userId];
          if (user.discountApplication && user.discountApplication.status === 'pending') {
            pendingCount++;
          }
        });

        const badge = document.getElementById('discountBadge');
        if (badge) {
          badge.textContent = pendingCount;
          badge.style.display = pendingCount > 0 ? 'inline-block' : 'none';
        }
      }
    }, (error) => {
      // Error loading discount applications
    });

  } catch (error) {
    showMessage('Error initializing dashboard: ' + error.message, 'error');
  }
}

// Load dashboard statistics
function loadStats() {
  // Load drivers count
  const driversRef = ref(db, 'drivers');
  onValue(driversRef, (snapshot) => {
    const count = snapshot.exists() ? Object.keys(snapshot.val()).length : 0;
    document.getElementById('totalDrivers').textContent = count;
  });

  // Load bookings count
  const bookingsRef = ref(db, 'bookings');
  onValue(bookingsRef, (snapshot) => {
    const count = snapshot.exists() ? Object.keys(snapshot.val()).length : 0;
    document.getElementById('totalBookings').textContent = count;
  });

  // Load contributions total
  const contributionsRef = ref(db, 'contributions');
  onValue(contributionsRef, (snapshot) => {
    if (snapshot.exists()) {
      const contributions = snapshot.val();
      let total = 0;
      let count = 0;
      
      Object.keys(contributions).forEach(key => {
        const amount = parseFloat(contributions[key].amount) || 0;
        total += amount;
        count++;
      });
      
      document.getElementById('totalContributions').textContent = `₱${total.toFixed(2)}`;
    } else {
      document.getElementById('totalContributions').textContent = '₱0.00';
    }
  });

  // Load queue count
  const queueRef = ref(db, 'driverQueue');
  onValue(queueRef, (snapshot) => {
    const count = snapshot.exists() ? Object.keys(snapshot.val()).length : 0;
    document.getElementById('queueCount').textContent = count;
  });
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', initializeDashboard);

